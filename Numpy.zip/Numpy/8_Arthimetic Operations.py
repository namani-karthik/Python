import numpy as np 
a = np.arange(9, dtype = np.float_).reshape(3,3) 

print ('First array:') 
print (a)   

print ('Second array:') 
b = np.array([10,10,10]) 
print (b)   

print ('Add the two arrays:' )
print (np.add(a,b))   

print ('Subtract the two arrays:' )
print (np.subtract(a,b))   

print ('Multiply the two arrays:') 
print (np.multiply(a,b))   

print ('Divide the two arrays:') 
print (np.divide(a,b))

a = np.array([10,100,1000]) 

print ('Our array is:') 
print (a)   

print ('Applying power function:') 
print (np.power(a,2))   

print ('Second array:') 
b = np.array([1,2,3]) 
print (b)  

print ('Applying power function again:') 
print (np.power(a,b))
