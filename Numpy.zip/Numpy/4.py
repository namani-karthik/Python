# Array creation from a sequence
import numpy as np
'''x=[1,2,3]
a=np.asarray(x)
print(a)
print(type(a))'''


'''x=[1,2,3]
a=np.asarray(x,dtype=float)
print(a)

x=(1,2,3)
a=np.asarray(x)
print(a)'''

'''x=[(1,2,3),(2,3)]
a=np.asarray(x)
print(a)
'''
#numpy.fromiter(iterable, dtype, count = -1)

lst=range(5)
it=iter(lst)
x=np.fromiter(it,dtype=int)
print(type(x)) 

#arange
