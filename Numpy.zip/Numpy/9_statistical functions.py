import numpy as np 
a = np.array([[3,7,5],[8,4,3],[2,4,9]]) 

print ('Our array is:') 
print (a)    

print ('Applying amin() function:') 
print (np.amin(a,1))   

print ('Applying amin() function again:') 
print (np.amin(a,0))  

print ('Applying amax() function:') 
print (np.amax(a))   

print ('Applying amax() function again:') 
print (np.amax(a, axis = 0))

a = np.array([[30,40,70],[80,20,10],[50,90,60]]) 

print ('Our array is:') 
print (a)   

print ('Applying percentile() function:') 
print (np.percentile(a,50))   

print ('Applying percentile() function along axis 1:' )
print (np.percentile(a,50, axis = 1))   

print ('Applying percentile() function along axis 0:') 
print (np.percentile(a,50, axis = 0))
