import numpy as np

'''a=np.array([[1,2,3],[3,4,5]])
print(a)
print(a.shape)

a=np.array([[2,3,4],[5,6,7]])
print('Shape of Original a is:', a.shape)
print(a)
a.shape=(3,2)
b=a.reshape(3,2)
print(a)
print(b)

a=np.arange(24)
b=a.reshape(2,4,3)
print(a)
print(b)

x=np.array([1,2,3,4,5],dtype=np.int8)
print(x.itemsize)'''

x=np.array([1,2,3,4,5],dtype=np.float32)
print(x.itemsize)
