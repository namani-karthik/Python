import numpy as np 
a = np.array([1.0,5.55, 123, 0.567, 25.532]) 
'''
print ('Original array:') 
print (a )

print ('After rounding:' )
print (np.around(a) )
print (np.around(a, decimals = 1))

a = np.array([-1.7, 1.5, -0.2, 0.6, 10]) 
print ('The given array:') 
print (a) 

print ('The modified array:') 
print (np.floor(a))
'''
a = np.array([-1.7, 1.5, -0.2, 0.6, 10]) 

print ('The given array:') 
print (a)   

print ('The modified array:') 
print (np.ceil(a))
