import numpy as np

print ('Standard Deviation is:',np.std([1,2,3,4]))

print ('Variance is:',np.var([1,2,3,4]))
