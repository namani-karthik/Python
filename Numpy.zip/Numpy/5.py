# Indexing and Slicing

import numpy as np 
'''
a = np.arange(10) 
s = slice(2,7,2) 
print(a[s])

a = np.arange(10) 
b = a[2:7:2] 
print(b)
'''
a = np.arange(10) 
b = a[5] 
print(b)
'''
a = np.arange(10) 
print(a[2:])

a = np.arange(10) 
print(a[2:5])

a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 
print(a)  

# slice items starting from index
print ('Now we will slice the array from the index a[1:]') 
print(a[1:])

a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 

print 'Our array is:' 
print a 
print '\n'  

# this returns array of items in the second column 
print 'The items in the second column are:'  
print a[...,1] 
print '\n'  

# Now we will slice all items from the second row 
print 'The items in the second row are:' 
print a[1,...] 
print '\n'  

# Now we will slice all items from column 1 onwards 
print 'The items column 1 onwards are:' 
print a[...,1'''
