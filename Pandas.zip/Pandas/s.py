import pandas as pd
import numpy as np

data=np.array(['a','b','c','d','e'])
s=pd.Series(data)
print(s)
