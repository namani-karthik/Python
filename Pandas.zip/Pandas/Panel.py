# creating an empty panel
import pandas as pd
import numpy as np
#From 3D ndarray

data = np.random.rand(2,4,5)
p = pd.Panel(data)
print(p)
'''
data = np.random.rand(2,4,5)
p = pd.Panel(data)
print p

#From dict of DataFrame Objects

data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
   'Item2' : pd.DataFrame(np.random.randn(4, 2))}
p = pd.Panel(data)
print p

#Create an Empty Panel
p = pd.Panel()
print p

#Selecting the Data from Panel
data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
   'Item2' : pd.DataFrame(np.random.randn(4, 2))}
p = pd.Panel(data)
print p['Item1']

#Using major_axis
data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
   'Item2' : pd.DataFrame(np.random.randn(4, 2))}
p = pd.Panel(data)

#Usingminor_axis 
data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
   'Item2' : pd.DataFrame(np.random.randn(4, 2))}
p = pd.Panel(data)
print p.minor_xs(1)
print p.major_xs(1)
'''
