# A series can be created using various inputs like Array, Dict ,scalar value or constant

import pandas as pd
import numpy as np
'''
data=np.array(['a','b','c','d','e'])
s=pd.Series(data)
print(s)

data=np.array(['a','b','c','d','e'])
s=pd.Series(data,index=[100,200,300,400,500])
print(s)

data={'a':1,'b':2,'c':3,'d':4}
s=pd.Series(data)
print(s)

s=pd.Series(5,index=[1,2,3,4,5])
print(s)
'''
s=pd.Series([1,2,3,4,5],index=['a','b','c','d','e'])
print(s[0])
print(s[3:])
print(s[:3])
print(s[-3:])
print(s['a'])

