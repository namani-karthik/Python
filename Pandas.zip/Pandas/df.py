import pandas as pd
import numpy as np

unsorted_df=pd.DataFrame({'col1':[2,1,1,1],'col2':[1,3,2,4]})
sorted_df=unsorted_df.sort_values(by='col2')
print(unsorted_df)


print(sorted_df)

'''
# creating an empty panel
import pandas as pd
import numpy as np
#From 3D ndarray

data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
   'Item2' : pd.DataFrame(np.random.randn(4, 2))}
p = pd.Panel(data)
print(p)
print('*****')
print (p.minor_xs(1))
print('*****')
print (p.major_xs(1))'''
